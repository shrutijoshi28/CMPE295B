/**
 * 
 */
package com.adrater.datacollection;

/**
 * @author Suraj Shetty
 *
 */
public class AdExtracter {

	private String currLink;
	private String nextLink;
	
	public void extractAds(String url){
		
		this.currLink = url;
		
	}
	
}
